Package Readme
-------------------------------------------------------------------------------
Name:				Milox-117's Cars Package

Version-No.:			5.1-A
-------------------------------------------------------------------------------
Author:				Fabulous Miss Luna (a.k.a Milox)

insults and complaints:		PokerMorda_Automovili@gmail.pl
-------------------------------------------------------------------------------
Mc-Version:			1.7.10

Flans Mod Version:		4.8.0

Depencies:			Flan's Simple Parts Package

Build with Forge Version:	1.7.10-10.13.2.1240
-------------------------------------------------------------------------------
This Package is free to download on www.minecraft-smp.de and flansmod.com 

If you downloaded it somewhere else or payed for it (single or as part of a
compilation) please report this to http://www.minecraft-smp.de.